from django.http import HttpResponse
from django.shortcuts import render, redirect
from store.models import Product
from .forms import SignupForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm


def home_1(request):
    return HttpResponse("Home page..")

def home(request):
    products = Product.objects.all()
    context = {'products': products}
    return render(request, 'home.html', context)

def signup(request):
    if request.method == "POST":
        fm = SignupForm(request.POST)
        if fm.is_valid():
            fm.save()
            return redirect("/signin")
    else:
        fm = SignupForm()

    return render(request, 'register.html', {'reg_fm': fm})

def Signin(request):
        if request.method == "POST":
            fm = AuthenticationForm(request=request, data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request, user)  # username
                    return redirect("/signin")
        else:
            fm = AuthenticationForm()
        return render(request, "signin.html", {'user_data': fm})
