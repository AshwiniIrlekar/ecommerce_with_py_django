from django.contrib import admin
from django.urls import path
from .import views
urlpatterns = [

     # path('Data/',views.reg_details, name='data'),
]